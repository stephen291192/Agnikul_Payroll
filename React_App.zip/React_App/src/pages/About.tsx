import React from "react";

interface AboutProps {
  darkMode: boolean;
}

const About: React.FC<AboutProps> = ({ darkMode }) => {
  return (
    <div className={` ${darkMode ? "dark" : ""}`}>
      <div className="m-4">
        <h2 className={`text-2xl ${darkMode ? "text-blue-500" : ""}`}>
          Heading
        </h2>
      </div>
    </div>
  );
};

export default About;
